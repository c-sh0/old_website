#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>

int usage(char *progname);
int irc_connect(char *hostname, int ircport, char *irc_login, char *irc_data);
char *build_lookup(char *thiernick);
char *build_login(char *mynick);

int main(int argc, char *argv[])
{

FILE *in_file;    
char l_buffer[100];
int lsize, x, port;
char *login, *data, *irc_server;

   if (argc != 4) {
           usage(argv[0]); 
        exit(1);  
    }

           login = build_login(argv[1]);
           data = build_lookup(argv[2]);

           in_file = fopen(argv[3],"r");
   
                 if(in_file == NULL) {
                      perror(argv[3]); 
                     exit(-1);
                 } 

printf("#-------------------------------------------------#\n");
printf("            ircsearch v0.1 beta\n\n");
printf(" noconflic\n");
printf(" http://nocon.darkflame.net\n");
printf(" nocon@darkflame.net\n");
printf("#-------------------------------------------------#\n");

printf("Starting...\n");

while( fgets(l_buffer,sizeof(l_buffer),in_file) != NULL) { 

            lsize=strlen(l_buffer);
      
     for(x=0;x<lsize;x++) {

          if(l_buffer[x] == '#' || lsize == 1) { 
               break; 

          } else if(strstr(l_buffer,":") != NULL) {
          
              irc_server = strtok(l_buffer,":");
              port = atoi(strtok(NULL, ":")); 

	           irc_connect(irc_server,port,login,data); 

               break;

          } else {

               break;
         }
       }

}

  fclose(in_file);
   printf("Finished.\n");
 return(0);
}


/*************** IRC Connect and get Info **********************/

int irc_connect(char *hostname, int ircport, char *irc_login, char *irc_data)
{
FILE *out_file;
struct sockaddr_in saddr;
struct hostent *host;
char receive[2024];
int s,numbytes;
 
       out_file = fopen("ircsearch.log","a");
		if(out_file == NULL) {
                      perror("ircsearch.log");
                      printf("Exiting!\n");
                    exit(-1);
                 }
           
              host = gethostbyname(hostname);
                   if (host == NULL) {
                     perror("gethostbyname");
                   }
  
      memcpy((char *)&saddr.sin_addr,(char *)host->h_addr, host->h_length);

 memset(&(receive),0,sizeof(receive));

    s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
           if(s == -1) {
                 perror("socket");
              return(1);
	    }

     saddr.sin_family = host->h_addrtype;
     saddr.sin_port = htons(ircport);

printf("Connecting to %s port: %d... ",hostname,ircport);
          fprintf(out_file,"Server: %s port: %d\n",hostname,ircport);
           fprintf(out_file," \r\n");
 
        if (connect(s, (struct sockaddr *)&saddr, sizeof(saddr)) < 0) {
         perror(hostname);
 	 return(1);
	}

    printf("Connected!\n");
sleep(2);

/* send our info */
if( send(s, irc_login, strlen(irc_login), 0) == -1) {
   perror("Write to socket\n");
   return(1);
} 

while((numbytes = recv(s, receive, (sizeof(receive)-1),0))) {
  receive[numbytes] = '\0';

         if(strstr(receive,":End of /MOTD") != NULL) {
                 send(s,irc_data,strlen(irc_data),0);
                  sleep(2);
                 numbytes = recv(s, receive, (sizeof(receive)-1),0);
                 receive[numbytes] = '\0';

                 fprintf(out_file,receive);
                 fprintf(out_file,"\n#-----------------------------------------#\n\n");
          }
  memset(&(receive),0,sizeof(receive));
}

    close(s);
    fclose(out_file);

 return(1);
}


/******************** Build IRC Login Info *****************/

char *build_login(char *mynick)
{
static char irc_login[256];

   if(strlen(mynick) > sizeof(irc_login)) {
          printf("[X] Error: irc nick too big!\n");
        exit(1);
   }

              memset(&(irc_login),0,sizeof(irc_login));

        strcpy(irc_login,"user ");
        strcat(irc_login,mynick);
        strcat(irc_login," - - -\r\n");

        strcat(irc_login,"nick ");
        strcat(irc_login,mynick);
        strcat(irc_login,"\r\n");

  return(irc_login);
}



/******************** Build Commands we are sending to Server ******************/

char *build_lookup(char *thiernick)
{

int x=0;
static char ircdata[256];
char *irc_command[] = {
                         "whowas ",
                         "whois ",
                         "ison ",
                         "who ",
                         "userhost ",
                         "dns ",
                  NULL };

    if(strlen(thiernick) > sizeof(ircdata)) {
             printf("[X] Error: irc nick too big!\n");
          exit(1);
    }
           memset(&(ircdata),0,sizeof(ircdata));

		while(irc_command[x] != NULL) {
		    strcat(ircdata,irc_command[x]);
		    strcat(ircdata,thiernick);
		    strcat(ircdata,"\r\n");
		  ++x;
	 	 }

        strcat(ircdata,"quit\r\n");

  return(ircdata);
}


/************************ Usage Function *************/

int usage(char *progname)
{
     printf("\nusage: [yournick] [nick-to-search] [ircserver.file]
            
        yournick        : Nickname to use when logging into an IRC server 
        nick-to-search  : Nickname you wish to search for
        ircserver.file  : Filename to read server list from

        output: written to \"ircsearch.log\"

 example:
        %s Mynam3 H0tLove ./server.list\n\n",progname);

  return(1);
} 

